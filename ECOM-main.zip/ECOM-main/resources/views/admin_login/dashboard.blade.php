@extends('admin_login.index')
@section('tittle', 'Dashboard')
@section('dashboard_selected', 'active')
@section('content')
   <h1>Dashboard</h1>
@stop